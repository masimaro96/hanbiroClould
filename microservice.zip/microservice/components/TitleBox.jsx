import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';


function TitleBox(title, content) {
    return (
        <Box style={Wrapper}>
            <Typography variant="h4" style={Title}>{title}</Typography>
            <Box style={BoxContainer}>
                {content.map(sentence => (
                <Typography variant="body1" style={Content}>{sentence}</Typography>
                ))}
            </Box>
        </Box>
    )
}

const Title = {
    fontSize: "16pt",
    fontWeight: "bold",
}

const Content = {
    lineHeight: "2em",
}

const Wrapper =  {
    textAlign: "left",
    /* media queries */
    "@media (max-width: 767px)": {
        fontSize: "80%",
    },   
}

const BoxContainer = {
    boxShadow: "0 0.375rem 1.5rem 0 rgb(140 152 164 / 13%)",
    border: "1px solid #E7EAF3",
    borderRadius: "8px",
    padding: "20px",
    marginBottom: "30px",
    marginTop: "20px",
    textAlign: "left",
}

export default TitleBox;