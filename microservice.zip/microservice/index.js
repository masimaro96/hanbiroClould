import React from 'react';


const Pagedetails = () => {

    return (
        <header>
            <MSA1 />
            <MSA2 />
        </header>


    );
};

export default Pagedetails;